package br.ufpe.cin.android.podcast

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.itemlista.*
import org.jetbrains.anko.doAsync
import org.jetbrains.anko.sdk27.coroutines.onClick
import java.net.URL

class MainActivity : AppCompatActivity() {
    var feedItems: List<ItemFeed>? = null
    val xmlDownloadLink = "http://joeroganexp.joerogan.libsynpro.com/rss"

    private lateinit var viewAdapter: RecyclerView.Adapter<*>
    private lateinit var viewManager: RecyclerView.LayoutManager


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_main)

        var feedItems: List<ItemFeed>

        item_action.onClick {
            doAsync {
                val feed = URL(xmlDownloadLink).readText()

                feedItems = Parser.parse(feed)

                listRecyclerView.apply {
                    viewManager = LinearLayoutManager(this@MainActivity)

                    viewAdapter = FeedItemAdapter(feedItems, this@MainActivity)
                }

            }
        }

    }




}
